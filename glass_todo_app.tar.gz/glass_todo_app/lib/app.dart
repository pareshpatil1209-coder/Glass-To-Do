import 'package:flutter/material.dart';
import 'package:glass_todo_app/core/theme/app_theme.dart';
import 'package:glass_todo_app/features/todos/presentation/screens/home_screen.dart';

class GlassTodoApp extends StatelessWidget {
  const GlassTodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Glass Todos',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
    );
  }
}
