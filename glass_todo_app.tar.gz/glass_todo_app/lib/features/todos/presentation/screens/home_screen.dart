import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:glass_todo_app/core/widgets/glass_container.dart';
import 'package:glass_todo_app/features/todos/data/models/todo_model.dart';
import 'package:glass_todo_app/features/todos/presentation/providers/todos_provider.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  final _controller = TextEditingController();
  late AnimationController _lightController;

  @override
  void initState() {
    super.initState();
    _lightController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    _lightController.dispose();
    super.dispose();
  }

  void _addTodo() {
    final text = _controller.text;
    if (text.trim().isEmpty) return;
    HapticFeedback.mediumImpact();
    ref.read(todosProvider.notifier).add(text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final todos = ref.watch(todosProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final size = MediaQuery.sizeOf(context);

    return Scaffold(
      body: Stack(
        children: [
          // Soft animated lighting background
          AnimatedBuilder(
            animation: _lightController,
            builder: (context, _) {
              return CustomPaint(
                size: size,
                painter: _LightPainter(
                  progress: _lightController.value,
                  isDark: isDark,
                ),
              );
            },
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GlassContainer(
                    borderRadius: 32,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 18),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Glass Todos',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.5,
                                    ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${todos.where((t) => !t.isCompleted).length} remaining',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                        if (todos.any((t) => t.isCompleted))
                          IconButton(
                            onPressed: () {
                              HapticFeedback.selectionClick();
                              ref.read(todosProvider.notifier).clearCompleted();
                            },
                            icon: const Icon(Icons.cleaning_services_rounded),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: todos.isEmpty
                      ? _EmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                          itemCount: todos.length,
                          itemBuilder: (context, index) {
                            return _TodoTile(
                              todo: todos[index],
                              index: index,
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          // Bottom input glass bar
          Positioned(
            left: 16,
            right: 16,
            bottom: 24 + MediaQuery.paddingOf(context).bottom,
            child: GlassContainer(
              borderRadius: 32,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Add a soft task…',
                        border: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 16),
                        hintStyle: TextStyle(
                          color: isDark ? Colors.white54 : Colors.black45,
                        ),
                      ),
                      onSubmitted: (_) => _addTodo(),
                      textInputAction: TextInputAction.done,
                    ),
                  ),
                  const SizedBox(width: 4),
                  GlassContainer(
                    borderRadius: 24,
                    onTap: _addTodo,
                    padding: const EdgeInsets.all(12),
                    child: const Icon(Icons.add_rounded, size: 26),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TodoTile extends ConsumerWidget {
  final TodoModel todo;
  final int index;

  const _TodoTile({required this.todo, required this.index});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassContainer(
        borderRadius: 26,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        onTap: () {
          HapticFeedback.selectionClick();
          ref.read(todosProvider.notifier).toggle(todo.id);
        },
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 12),
          leading: AnimatedContainer(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: todo.isCompleted
                  ? Theme.of(context).colorScheme.primary.withOpacity(0.85)
                  : Colors.transparent,
              border: Border.all(
                color: todo.isCompleted
                    ? Colors.transparent
                    : (isDark ? Colors.white38 : Colors.black26),
                width: 1.6,
              ),
            ),
            child: todo.isCompleted
                ? const Icon(Icons.check_rounded, size: 16, color: Colors.white)
                : null,
          ),
          title: AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 280),
            style: TextStyle(
              fontSize: 16.5,
              fontWeight: FontWeight.w500,
              decoration: todo.isCompleted
                  ? TextDecoration.lineThrough
                  : TextDecoration.none,
              color: todo.isCompleted
                  ? Colors.grey
                  : (isDark ? Colors.white : Colors.black87),
            ),
            child: Text(todo.title),
          ),
          trailing: IconButton(
            icon: Icon(
              Icons.close_rounded,
              size: 20,
              color: isDark ? Colors.white54 : Colors.black45,
            ),
            onPressed: () {
              HapticFeedback.lightImpact();
              ref.read(todosProvider.notifier).delete(todo.id);
            },
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: GlassContainer(
        borderRadius: 36,
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.auto_awesome_rounded,
              size: 48,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 16),
            Text(
              'Nothing here yet',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 6),
            Text(
              'Add your first soft task below',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LightPainter extends CustomPainter {
  final double progress;
  final bool isDark;

  _LightPainter({required this.progress, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final colors = isDark
        ? [
            const Color(0xFF1A1C2E),
            const Color(0xFF12141F),
            const Color(0xFF0F1117),
          ]
        : [
            const Color(0xFFE8EEFF),
            const Color(0xFFF4F6FB),
            const Color(0xFFF0E8FF),
          ];

    final rect = Offset.zero & size;
    final gradient = LinearGradient(
      begin: Alignment(-1 + progress * 0.6, -1),
      end: Alignment(1 - progress * 0.4, 1),
      colors: colors,
    );

    canvas.drawRect(rect, Paint()..shader = gradient.createShader(rect));

    // Soft floating light orbs
    final orbPaint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60);

    orbPaint.color = (isDark ? const Color(0xFF7C9EFF) : const Color(0xFFB8C7FF))
        .withOpacity(0.25);
    canvas.drawCircle(
      Offset(size.width * (0.2 + progress * 0.3), size.height * 0.25),
      120,
      orbPaint,
    );

    orbPaint.color = (isDark ? const Color(0xFFC084FC) : const Color(0xFFE0C3FF))
        .withOpacity(0.18);
    canvas.drawCircle(
      Offset(size.width * (0.8 - progress * 0.2), size.height * 0.7),
      140,
      orbPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _LightPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.isDark != isDark;
}
