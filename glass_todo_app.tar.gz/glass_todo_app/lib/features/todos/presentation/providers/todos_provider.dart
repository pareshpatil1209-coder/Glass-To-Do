import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import 'package:glass_todo_app/features/todos/data/models/todo_model.dart';

final todosProvider =
    StateNotifierProvider<TodosNotifier, List<TodoModel>>((ref) {
  return TodosNotifier();
});

class TodosNotifier extends StateNotifier<List<TodoModel>> {
  TodosNotifier() : super([]) {
    _load();
  }

  final _box = Hive.box<TodoModel>('todos');
  final _uuid = const Uuid();

  void _load() {
    state = _box.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<void> add(String title, {int priority = 1}) async {
    if (title.trim().isEmpty) return;
    final todo = TodoModel(
      id: _uuid.v4(),
      title: title.trim(),
      createdAt: DateTime.now(),
      priority: priority,
    );
    await _box.put(todo.id, todo);
    _load();
  }

  Future<void> toggle(String id) async {
    final todo = _box.get(id);
    if (todo == null) return;
    await _box.put(id, todo.copyWith(isCompleted: !todo.isCompleted));
    _load();
  }

  Future<void> delete(String id) async {
    await _box.delete(id);
    _load();
  }

  Future<void> clearCompleted() async {
    final completed = state.where((t) => t.isCompleted).map((t) => t.id);
    await _box.deleteAll(completed);
    _load();
  }
}
