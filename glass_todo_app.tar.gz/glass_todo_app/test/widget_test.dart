import 'package:flutter_test/flutter_test.dart';
import 'package:glass_todo_app/features/todos/data/models/todo_model.dart';

void main() {
  test('TodoModel copyWith works', () {
    final original = TodoModel(
      id: '1',
      title: 'Test',
      createdAt: DateTime(2026),
    );
    final updated = original.copyWith(isCompleted: true);
    expect(updated.isCompleted, true);
    expect(updated.title, 'Test');
  });
}
